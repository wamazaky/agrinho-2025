let elementosCampo = [];
let elementosCidade = [];
let conexoesCorretas = [];
let conexoesFeitas = [];
let arrastando = false;
let elementoSelecionado = null;
let pontuacao = 0;
let fase = 1;

function setup() {
  createCanvas(800, 600);
  inicializarFase(fase);
}

function draw() {
  background(220); // Cor de fundo suave

  // Desenhar elementos do campo
  for (let el of elementosCampo) {
    fill(0, 150, 0); // Verde para o campo
    rect(el.x, el.y, el.largura, el.altura, 10); // Retângulo com bordas arredondadas
    fill(255);
    textAlign(CENTER, CENTER);
    textSize(16);
    text(el.nome, el.x + el.largura / 2, el.y + el.altura / 2);
  }

  // Desenhar elementos da cidade
  for (let el of elementosCidade) {
    fill(100, 100, 150); // Azul acinzentado para a cidade
    rect(el.x, el.y, el.largura, el.altura, 10);
    fill(255);
    textAlign(CENTER, CENTER);
    textSize(16);
    text(el.nome, el.x + el.largura / 2, el.y + el.altura / 2);
  }

  // Desenhar as conexões já feitas
  for (let con of conexoesFeitas) {
    stroke(0, 100, 200, 150); // Cor da linha das conexões feitas
    strokeWeight(3);
    line(con.origem.x + con.origem.largura / 2, con.origem.y + con.origem.altura / 2,
         con.destino.x + con.destino.largura / 2, con.destino.y + con.destino.altura / 2);
  }

  // Desenhar a linha de arrasto atual
  if (arrastando && elementoSelecionado) {
    stroke(255, 0, 0, 150); // Linha vermelha enquanto arrasta
    strokeWeight(3);
    line(elementoSelecionado.x + elementoSelecionado.largura / 2, elementoSelecionado.y + elementoSelecionado.altura / 2,
         mouseX, mouseY);
  }

  // Exibir pontuação e fase
  fill(50);
  textSize(20);
  textAlign(LEFT, TOP);
  text(`Pontuação: ${pontuacao}`, 20, 20);
  text(`Fase: ${fase}`, 20, 50);

  // Mensagem de vitória/próxima fase
  if (conexoesFeitas.length === conexoesCorretas.length && conexoesCorretas.length > 0) {
    fill(0, 180, 0, 200);
    rect(width / 2 - 200, height / 2 - 50, 400, 100, 20);
    fill(255);
    textAlign(CENTER, CENTER);
    textSize(24);
    text("Fase Concluída! Clique para a próxima fase.", width / 2, height / 2);
  }
}

function mousePressed() {
  if (conexoesFeitas.length === conexoesCorretas.length && conexoesCorretas.length > 0) {
    // Se a fase foi concluída, avança para a próxima
    fase++;
    inicializarFase(fase);
    pontuacao += 10; // Bônus por concluir a fase
    return;
  }

  for (let el of elementosCampo) {
    if (mouseX > el.x && mouseX < el.x + el.largura &&
        mouseY > el.y && mouseY < el.y + el.altura) {
      arrastando = true;
      elementoSelecionado = el;
      break;
    }
  }
}

function mouseReleased() {
  if (arrastando && elementoSelecionado) {
    for (let elCidade of elementosCidade) {
      if (mouseX > elCidade.x && mouseX < elCidade.x + elCidade.largura &&
          mouseY > elCidade.y && mouseY < elCidade.y + elCidade.altura) {
        // Tentativa de conexão
        tentarConectar(elementoSelecionado, elCidade);
        break;
      }
    }
  }
  arrastando = false;
  elementoSelecionado = null;
}

function tentarConectar(campoEl, cidadeEl) {
  let conectouCorretamente = false;
  for (let con of conexoesCorretas) {
    if ((con.campo === campoEl.id && con.cidade === cidadeEl.id) ||
        (con.campo === cidadeEl.id && con.cidade === campoEl.id)) { // Permite conexão nos dois sentidos se fizer sentido
      // Verifica se a conexão já foi feita
      let jaFeito = conexoesFeitas.some(c =>
        (c.origem === campoEl && c.destino === cidadeEl) ||
        (c.origem === cidadeEl && c.destino === campoEl)
      );

      if (!jaFeito) {
        conexoesFeitas.push({ origem: campoEl, destino: cidadeEl });
        pontuacao += 10; // Ganha pontos
        conectouCorretamente = true;
      }
      break;
    }
  }

  if (!conectouCorretamente) {
    pontuacao = max(0, pontuacao - 5); // Perde alguns pontos se errar
  }
}

function inicializarFase(numeroFase) {
  elementosCampo = [];
  elementosCidade = [];
  conexoesCorretas = [];
  conexoesFeitas = [];

  // Posições fixas para os elementos para esta versão simples
  let larguraElemento = 120;
  let alturaElemento = 80;
  let espacamentoY = 100;
  let xCampo = width / 4 - larguraElemento / 2;
  let xCidade = width * 3 / 4 - larguraElemento / 2;

  if (numeroFase === 1) {
    // Campo
    elementosCampo.push({ id: 'trator', nome: 'Trator', x: xCampo, y: height / 2 - espacamentoY, largura: larguraElemento, altura: alturaElemento });
    elementosCampo.push({ id: 'vaca', nome: 'Vaca', x: xCampo, y: height / 2, largura: larguraElemento, altura: alturaElemento });
    elementosCampo.push({ id: 'plantação', nome: 'Plantação', x: xCampo, y: height / 2 + espacamentoY, largura: larguraElemento, altura: alturaElemento });

    // Cidade
    elementosCidade.push({ id: 'supermercado', nome: 'Supermercado', x: xCidade, y: height / 2 - espacamentoY, largura: larguraElemento, altura: alturaElemento });
    elementosCidade.push({ id: 'laticinio', nome: 'Laticínio', x: xCidade, y: height / 2, largura: larguraElemento, altura: alturaElemento });
    elementosCidade.push({ id: 'restaurante', nome: 'Restaurante', x: xCidade, y: height / 2 + espacamentoY, largura: larguraElemento, altura: alturaElemento });

    // Conexões corretas para a Fase 1
    conexoesCorretas.push({ campo: 'trator', cidade: 'supermercado' }); // Trator -> Alimentos -> Supermercado
    conexoesCorretas.push({ campo: 'vaca', cidade: 'laticinio' });     // Vaca -> Leite -> Laticínio
    conexoesCorretas.push({ campo: 'plantação', cidade: 'restaurante' }); // Plantação -> Vegetais -> Restaurante

  } else if (numeroFase === 2) {
    // Exemplo de elementos para a Fase 2 (adicione mais conforme necessário)
    elementosCampo.push({ id: 'algodao', nome: 'Algodão', x: xCampo, y: height / 2 - espacamentoY, largura: larguraElemento, altura: alturaElemento });
    elementosCampo.push({ id: 'madeira', nome: 'Madeira', x: xCampo, y: height / 2, largura: larguraElemento, altura: alturaElemento });
    elementosCampo.push({ id: 'apicultor', nome: 'Apicultor', x: xCampo, y: height / 2 + espacamentoY, largura: larguraElemento, altura: alturaElemento });

    elementosCidade.push({ id: 'fabricaTextil', nome: 'Fábrica Têxtil', x: xCidade, y: height / 2 - espacamentoY, largura: larguraElemento, altura: alturaElemento });
    elementosCidade.push({ id: 'moveleira', nome: 'Moveleira', x: xCidade, y: height / 2, largura: larguraElemento, altura: alturaElemento });
    elementosCidade.push({ id: 'farmacia', nome: 'Farmácia', x: xCidade, y: height / 2 + espacamentoY, largura: larguraElemento, altura: alturaElemento }); // Mel na farmácia

    conexoesCorretas.push({ campo: 'algodao', cidade: 'fabricaTextil' });
    conexoesCorretas.push({ campo: 'madeira', cidade: 'moveleira' });
    conexoesCorretas.push({ campo: 'apicultor', cidade: 'farmacia' });

  } else {
    // Fim do jogo ou mais faseshttps://
    elementosCampo = [];
    elementosCidade = [];
    fill(0, 180, 0, 200);
    rect(width / 2 - 250, height / 2 - 75, 500, 150, 20);
    fill(255);
    textAlign(CENTER, CENTER);
    textSize(32);
    text("Parabéns! Você conectou o Campo e a Cidade!", width / 2, height / 2 - 20);
    textSize(24);
    text(`Pontuação Final: ${pontuacao}`, width / 2, height / 2 + 30);
  }
}